package com.infin8.cleaner

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat

private val Bg = Color(0xFF080D0B)
private val Panel = Color(0xFF111B16)
private val Green = Color(0xFF36D98A)
private val Muted = Color(0xFF9AA9A0)

data class Candidate(val uri: Uri, val name: String, val size: Long, val modified: Long)

class MainActivity : ComponentActivity() {
    private var scanFolder by mutableStateOf<Uri?>(null)

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            scanFolder = uri
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Green, background = Bg, surface = Panel,
                onBackground = Color.White, onSurface = Color.White
            )) {
                CleanerScreen(
                    folderUri = scanFolder,
                    chooseFolder = { folderPicker.launch(null) },
                    resolver = contentResolver
                )
            }
        }
    }
}

@Composable
private fun CleanerScreen(
    folderUri: Uri?,
    chooseFolder: () -> Unit,
    resolver: android.content.ContentResolver
) {
    var candidates by remember { mutableStateOf<List<Candidate>>(emptyList()) }
    var scanning by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Choose a folder you want to inspect.") }
    var selected by remember { mutableStateOf<Set<Uri>>(emptySet()) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    fun scan() {
        val uri = folderUri ?: return
        scanning = true
        status = "Scanning selected folder…"
        scope.launch {
            val found = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(resolverContext(resolver), uri)
                val now = System.currentTimeMillis()
                val minAge = 24L * 60 * 60 * 1000
                val result = mutableListOf<Candidate>()
                fun walk(dir: DocumentFile, depth: Int) {
                    if (depth > 8 || result.size >= 3000) return
                    dir.listFiles().forEach { file ->
                        if (file.isDirectory) {
                            // Avoid well-known app-private/system-like directories.
                            if (file.name !in setOf("Android", "Android/data", "Android/obb")) walk(file, depth + 1)
                        } else {
                            val name = file.name ?: return@forEach
                            val lower = name.lowercase()
                            val modified = file.lastModified()
                            val isTempName = lower.endsWith(".tmp") || lower.endsWith(".temp") ||
                                lower.endsWith(".part") || lower.endsWith(".download")
                            // Only list old candidates; never assume every temp extension is safe.
                            if (isTempName && modified > 0 && now - modified >= minAge) {
                                result.add(Candidate(file.uri, name, file.length(), modified))
                            }
                        }
                    }
                }
                if (root != null) walk(root, 0)
                result
            }
            candidates = found
            selected = emptySet()
            scanning = false
            status = if (found.isEmpty()) "No old temporary-file candidates found." else
                "Found ${found.size} candidates. Review each item before deleting."
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("INFIN8", color = Green, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Text("Cleaner", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
                Text("Private • Offline • No root", color = Muted)
            }
            Icon(Icons.Default.Security, contentDescription = "Privacy", tint = Green, modifier = Modifier.size(36.dp))
        }

        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Storage review", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Select a folder using Android's system picker. The app can only inspect files you grant access to.", color = Muted)
                Button(onClick = chooseFolder, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.FolderOpen, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choose folder")
                }
                if (folderUri != null) {
                    OutlinedButton(onClick = { scan() }, enabled = !scanning, modifier = Modifier.fillMaxWidth()) {
                        Text(if (scanning) "Scanning…" else "Scan for old temporary files")
                    }
                }
            }
        }

        Text(status, color = Muted)
        if (candidates.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${candidates.size} candidates", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                Text("${selected.size} selected", color = Green)
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(candidates, key = { it.uri.toString() }) { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(
                                checked = item.uri in selected,
                                onCheckedChange = { checked ->
                                    selected = if (checked) selected + item.uri else selected - item.uri
                                }
                            )
                            Column(Modifier.weight(1f)) {
                                Text(item.name, fontWeight = FontWeight.SemiBold)
                                Text(formatBytes(item.size), color = Muted, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
            Button(
                onClick = { showDeleteDialog = true },
                enabled = selected.isNotEmpty(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB74747)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Review deletion (${selected.size})")
            }
        } else {
            Spacer(Modifier.weight(1f))
        }

        Text(
            "Safety: files are never deleted automatically. Only selected items inside the folder you authorized can be removed. This app cannot clear other apps' private caches or Android system files.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall
        )
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Delete selected files?") },
            text = { Text("This permanently deletes ${selected.size} selected items from the folder you granted access to. Check that none are in use.") },
            confirmButton = {
                TextButton(onClick = {
                    val targets = candidates.filter { it.uri in selected }
                    scope.launch {
                        val deleted = withContext(Dispatchers.IO) {
                            targets.count { resolver.delete(it.uri, null, null) > 0 }
                        }
                        candidates = candidates.filterNot { it.uri in selected }
                        selected = emptySet()
                        status = "Deleted $deleted of ${targets.size} selected files."
                        showDeleteDialog = false
                    }
                }) { Text("Delete", color = Color(0xFFFF7777)) }
            },
            dismissButton = { TextButton(onClick = { showDeleteDialog = false }) { Text("Cancel") } }
        )
    }
}

private fun resolverContext(resolver: android.content.ContentResolver): android.content.Context {
    // ContentResolver does not expose its Context; use the application singleton set by Activity.
    return AppContext.instance
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return "${DecimalFormat("#,##0.0").format(kb)} KB"
    return "${DecimalFormat("#,##0.0").format(kb / 1024)} MB"
}

class AppContext : android.app.Application() {
    override fun onCreate() { super.onCreate(); instance = this }
    companion object { lateinit var instance: AppContext }
}
