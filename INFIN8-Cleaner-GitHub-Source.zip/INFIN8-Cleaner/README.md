# INFIN8 Cleaner

Initial Android app project for a privacy-first, no-root storage review tool.

## Build with GitHub Actions
1. Upload the contents of this folder to the root of your `INFIN8-Cleaner` repository.
2. Commit to `main`.
3. Open **Actions** and select **Build INFIN8 Cleaner APK** (or wait for the push workflow).
4. Open the completed workflow run and download `INFIN8-Cleaner-debug-apk` under Artifacts.

## Current functionality
- Dark black / emerald Compose interface.
- Android Storage Access Framework folder picker.
- Scans only the selected folder for files ending in `.tmp`, `.temp`, `.part`, or `.download` that are at least 24 hours old.
- Requires manual selection and confirmation before deletion.
- Does not request broad storage access or root.
- Does not clear other apps' private caches or Android system storage.

## Important
This is an initial source package and has not been compiled on a real device in this environment. The first GitHub Actions run is the build verification step. Review the code and workflow before installing the APK. The scanner intentionally reports candidates, not guaranteed junk.
